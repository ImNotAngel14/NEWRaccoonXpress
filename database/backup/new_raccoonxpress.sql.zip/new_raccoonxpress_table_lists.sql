
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lists`
--

CREATE TABLE `lists` (
  `list_id` int(11) NOT NULL COMMENT 'Identificador de la lista de productos',
  `user_id` int(11) NOT NULL COMMENT 'Identificador del comprador',
  `title` varchar(32) NOT NULL COMMENT 'Titulo de la lista',
  `description` varchar(180) DEFAULT NULL COMMENT 'Descripción de la lista',
  `visibility` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Bandera de visibilidad de la lista',
  `list_image` blob DEFAULT NULL COMMENT 'Imagen de la lista'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
