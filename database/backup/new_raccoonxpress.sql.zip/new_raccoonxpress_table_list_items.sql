
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `list_items`
--

CREATE TABLE `list_items` (
  `list_item_id` int(11) NOT NULL COMMENT 'Identificador del producto en la lista',
  `list_id` int(11) NOT NULL COMMENT 'Identificador de la lista a la que pertenecen los productos',
  `product_id` int(11) NOT NULL COMMENT 'Identificador del producto en la lista'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
