
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paid_methods`
--

CREATE TABLE `paid_methods` (
  `paid_method_id` int(11) NOT NULL COMMENT 'Identificador del método de pago',
  `method_name` varchar(32) NOT NULL COMMENT 'Nombre del método de pago'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
