
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL COMMENT 'Identificador de producto',
  `product_name` varchar(64) NOT NULL COMMENT 'Nombre del producto',
  `description` varchar(160) NOT NULL COMMENT 'Descripción del producto',
  `quotable` tinyint(1) NOT NULL COMMENT 'Bandera de producto cotizable',
  `price` decimal(10,2) DEFAULT NULL COMMENT 'Precio del producto',
  `quantity` int(11) NOT NULL COMMENT 'Cantidad del producto',
  `active` tinyint(1) DEFAULT 0 COMMENT 'Bandera de producto activado',
  `approved_by` int(11) DEFAULT NULL COMMENT 'Identificador del usuario administrador quien aprovó el producto',
  `image_1` longblob DEFAULT NULL,
  `image_2` longblob DEFAULT NULL,
  `image_3` longblob DEFAULT NULL,
  `video` longblob DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
