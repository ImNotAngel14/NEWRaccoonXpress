
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL COMMENT 'Identificador de la reseña',
  `product_purchase_id` int(11) NOT NULL COMMENT 'Identificador del producto de la compra a la que hace referencia',
  `title` varchar(32) NOT NULL COMMENT 'Titulo de la reseña',
  `review_body` varchar(180) NOT NULL COMMENT 'Cuerpo de la reseña',
  `rate` int(11) NOT NULL COMMENT 'Calificación del producto',
  `active` tinyint(1) NOT NULL COMMENT 'Bandera de reseña activa',
  `created_at` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha y hora del envío del mensaje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
