
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sale_details`
--

CREATE TABLE `sale_details` (
  `sale_details_id` int(11) NOT NULL COMMENT 'Identificador del articulo de la venta',
  `sale_id` int(11) NOT NULL COMMENT 'Identificador de la venta',
  `product_id` int(11) NOT NULL COMMENT 'Idenfiticador del producto comprado',
  `quantity` int(11) NOT NULL COMMENT 'Cantidad del producto comprado',
  `individual_price` decimal(10,2) NOT NULL COMMENT 'Precio del producto al momento de la compra',
  `discount` decimal(10,2) NOT NULL COMMENT 'Cantidad descontada del precio del producto',
  `amount_paid` decimal(10,2) NOT NULL COMMENT 'Cantidad pagada por este producto'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
