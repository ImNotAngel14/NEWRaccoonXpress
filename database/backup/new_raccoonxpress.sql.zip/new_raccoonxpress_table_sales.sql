
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sales`
--

CREATE TABLE `sales` (
  `sale_id` int(11) NOT NULL COMMENT 'Identificador de la venta',
  `buyer_id` int(11) NOT NULL COMMENT 'Identificador del comprador',
  `sale_datetime` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha y hora en la que se realizó la venta',
  `amount_paid_total` decimal(10,2) NOT NULL COMMENT 'Cantidad pagada en la compra',
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantidad descontada a la compra',
  `paid_method` varchar(32) NOT NULL COMMENT 'Nombre del método de pago'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
