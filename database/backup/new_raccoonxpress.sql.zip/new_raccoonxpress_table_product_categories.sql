
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_categories`
--

CREATE TABLE `product_categories` (
  `product_id` int(11) NOT NULL COMMENT 'Identificador del producto',
  `category_id` int(11) NOT NULL COMMENT 'Identificador de la categoria'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
