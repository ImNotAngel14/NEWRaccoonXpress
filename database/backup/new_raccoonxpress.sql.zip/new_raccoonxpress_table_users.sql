
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL COMMENT 'Identificador de usuario',
  `email` varchar(64) NOT NULL COMMENT 'Correo electrónico del usuario',
  `username` varchar(32) NOT NULL COMMENT 'Nombre de usuario para la aplicación',
  `user_password` varchar(64) NOT NULL COMMENT 'Contraseña para el ingreso a la aplicación',
  `user_role` int(11) NOT NULL COMMENT 'Identificador del rol de usuario',
  `first_name` varchar(64) NOT NULL COMMENT 'Primer nombre real del usuario',
  `last_name` varchar(64) NOT NULL COMMENT 'Apellido real del usuario',
  `gender` int(11) NOT NULL COMMENT 'Género del usuario',
  `birth_date` date NOT NULL COMMENT 'Fecha de nacimiento del usuario',
  `visibility` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Visibilidad del perfil del usuario',
  `active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Bandera de usuario activo',
  `last_login_date` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'fecha del último ingreso al portal',
  `profile_image` blob DEFAULT NULL COMMENT 'Imagen del perfil del usuario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
