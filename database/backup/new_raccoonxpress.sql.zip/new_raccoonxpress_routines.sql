
DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_authLogin` (IN `p_username` VARCHAR(32), IN `p_user_password` VARCHAR(64))   BEGIN
	SELECT `user_id`, `user_role` FROM `users`
	WHERE `username` COLLATE utf8mb4_bin  = `p_username`
	AND `user_password` COLLATE utf8mb4_bin = `p_user_password`
	AND `active` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_deactivate_user` (IN `p_user_id` INT)   BEGIN
	UPDATE `users` SET
    `active` = 0
    WHERE `user_id` = `p_user_id`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_user` (IN `p_user_id` INT, IN `p_is_owner` TINYINT(1))   BEGIN
    SELECT 
        `username`, 
        `profile_image`, 
        `user_role`, 
        `visibility`,
        IF(`p_is_owner`, `user_password`, NULL) AS `user_password`,
        IF(`p_is_owner`, `first_name`, NULL) AS `first_name`,
        IF(`p_is_owner`, `last_name`, NULL) AS `last_name`,
        IF(`p_is_owner`, `gender`, NULL) AS `gender`,
        IF(`p_is_owner`, `birth_date`, NULL) AS `birth_date`,
        IF(`p_is_owner`, `email`, NULL) AS `email`
    FROM 
        `users`
    WHERE
        `user_id` = `p_user_id`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_user_purchases` (IN `buyer_id` INT, IN `start_date` DATE, IN `end_date` DATE, IN `category_id` INT)   BEGIN
    SELECT 
        `s`.`sale_datetime`,
        `c`.`title` AS `category`,
        `p`.`product_name`,
        IFNULL(`r`.`rate`, 0.0) AS `rate`,
        `sd`.`individual_price`
    FROM sales s
    INNER JOIN `sale_details` `sd` ON `s`.`sale_id` = `sd`.`sale_id`
    INNER JOIN `products` `p` ON `sd`.`product_id` = `p`.`product_id`
    INNER JOIN `product_categories` `pc` ON `p`.`product_id` = `pc`.`product_id`
    INNER JOIN `categories` `c` ON `pc`.`category_id` = `c`.`category_id`
    LEFT JOIN `reviews` `r` ON `sd`.`sale_details_id` = `r`.`product_purchase_id`
    WHERE `s`.`buyer_id` = `buyer_id`
      AND (`start_date` IS NULL OR DATE(`s`.`sale_datetime`) >= `start_date`)
      AND (`end_date` IS NULL OR DATE(`s`.`sale_datetime`) <= `end_date`)
      AND (`category_id` IS NULL OR `c`.`category_id` = `category_id`)
    ORDER BY `s`.`sale_datetime` DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_product_search` (IN `p_search` VARCHAR(64), IN `p_filter_order` INT)   BEGIN
    SELECT 
        `product_id`, `product_name`, `price`, `quotable`, `average_rating`, `units_sold`, `image_1`, `image_2`, `image_3`, `video`
    FROM 
        `product_overview`
    WHERE
        `product_name` LIKE CONCAT('%', p_search, '%')
    ORDER BY
        CASE
            WHEN `p_filter_order` = 1 THEN `average_rating` END DESC,
        CASE
            WHEN `p_filter_order` = 2 THEN `price`END DESC,
        CASE
            WHEN `p_filter_order` = 3 THEN `price` END ASC,
        CASE
            WHEN `p_filter_order` = 4 THEN `units_sold` END DESC,
        CASE
            WHEN `p_filter_order` = 5 THEN `units_sold` END ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_register` (IN `p_email` VARCHAR(64), IN `p_username` VARCHAR(32), IN `p_user_password` VARCHAR(64), IN `p_user_role` TINYINT(1), IN `p_first_name` VARCHAR(64), IN `p_last_name` VARCHAR(64), IN `p_gender` TINYINT(1), IN `p_birth_date` DATE)   BEGIN
	INSERT INTO `users` (
        `email`,
        `username`,
        `user_password`, 
        `user_role`, 
        `first_name`, 
        `last_name`, 
        `gender`, 
        `birth_date`
    ) 
    VALUES (
        `p_email`,
        `p_username`,
        `p_user_password`,
        `p_user_role`,
        `p_first_name`,
        `p_last_name`,
        `p_gender`,
        `p_birth_date`
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sales_report` (IN `p_fecha_inicio` DATETIME, IN `p_fecha_fin` DATETIME, IN `p_categoria` INT)   BEGIN
    -- Consulta detallada
    SELECT 
        `s`.`sale_datetime` AS `sale_datetime`,
        `c`.`title` AS `category`,
        `p`.`product_name` AS `product`,
        IFNULL(`r`.`rate`, 0.0) AS `rating`,
        `sd`.`individual_price` AS `price`,
        `p`.`quantity` AS `inventory`
    FROM `sales` `s`
    INNER JOIN `sale_details` `sd` ON `s`.`sale_id` = `sd`.`sale_id`
    INNER JOIN `products` `p` ON `sd`.`product_id` = `p`.`product_id`
    INNER JOIN `product_categories` `pc` ON `p`.`product_id` = `pc`.`product_id`
    INNER JOIN `categories` `c` ON `pc`.`category_id` = `c`.`category_id`
    LEFT JOIN `reviews` `r` ON `sd`.`sale_details_id` = `r`.`product_purchase_id`
    WHERE 
        (`p_fecha_inicio` IS NULL OR DATE(`s`.`sale_datetime`) >= `p_fecha_inicio`)
        AND (`p_fecha_fin` IS NULL OR DATE(`s`.`sale_datetime`) <= `p_fecha_fin`)
        AND (`p_categoria` IS NULL OR `c`.`category_id` = `p_categoria`)
    ORDER BY `s`.`sale_datetime`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sales_report_grouped` (IN `p_fecha_inicio` DATETIME, IN `p_fecha_fin` DATETIME, IN `p_categoria` INT)   BEGIN
    -- Consulta agrupada
    SELECT 
        DATE_FORMAT(`s`.`sale_datetime`, '%Y-%m') AS `month_year`,
        `c`.`title` AS `category`,
        COUNT(*) AS `total_sales`
    FROM `sales` `s`
    INNER JOIN `sale_details` `sd` ON `s`.`sale_id` = `sd`.`sale_id`
    INNER JOIN `products` `p` ON `sd`.`product_id` = `p`.`product_id`
    INNER JOIN `product_categories` `pc` ON `p`.`product_id` = `pc`.`product_id`
    INNER JOIN `categories` `c` ON `pc`.`category_id` = `c`.`category_id`
    WHERE 
        (`p_fecha_inicio` IS NULL OR DATE(`s`.`sale_datetime`) >= `p_fecha_inicio`)
        AND (`p_fecha_fin` IS NULL OR DATE(`s`.`sale_datetime`) <= `p_fecha_fin`)
        AND (`p_categoria` IS NULL OR `c`.`category_id` = `p_categoria`)
    GROUP BY `month_year`, `c`.`title`
    ORDER BY `month_year`, `c`.`title`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_shopping_cart_management` (IN `p_user_id` INT, IN `p_product_id` INT, IN `p_quantity` INT, IN `p_operation` INT)   BEGIN
    -- Restar
	IF `p_operation` = 0 THEN
        DELETE FROM 
            `shopping_carts`
        WHERE 
            `user_id` = `p_user_id` 
            AND `product_id` = `p_product_id` 
            AND `quantity` <= 1;
        UPDATE `shopping_carts`
        SET `quantity` = `quantity` - 1
        WHERE `user_id` = `p_user_id` AND `product_id` = `p_product_id`;
    -- Agregar
    ELSEIF `p_operation` = 1 THEN
        INSERT INTO 
            `shopping_carts` (`user_id`, `product_id`, `quantity`)
        VALUES 
            (`p_user_id`, `p_product_id`, `p_quantity`)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity);
    ELSEIF `p_operation` = 2 THEN
        UPDATE `shopping_carts`
        SET `quantity` = `p_quantity`
        WHERE 
            `user_id` = `p_user_id`
            AND `product_id` = `p_product_id`;
    ELSEIF `p_operation` = 3 THEN
        DELETE FROM
            `shopping_carts`
        WHERE
            `user_id` = `p_user_id`
            AND `product_id` = `p_product_id`;
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_product` (IN `p_product_id` INT, IN `p_product_name` VARCHAR(64), IN `p_description` VARCHAR(160), IN `p_quotable` TINYINT(1), IN `p_price` DECIMAL(10,2), IN `p_quantity` INT, IN `p_image_1` LONGBLOB, IN `p_image_2` LONGBLOB, IN `p_image_3` LONGBLOB, IN `p_video` LONGBLOB)   BEGIN
    UPDATE `products`
    SET 
        `product_name` = `p_product_name`,
        `description` = `p_description`,
        `quotable` = `p_quotable`,
        `price` = `p_price`,
        `quantity` = `p_quantity`,
        `image_1` = CASE
            WHEN `p_image_1` IS NOT NULL THEN `p_image_1`
            ELSE `image_1`
        END,
        `image_2` = CASE 
            WHEN `p_image_2` IS NOT NULL THEN `p_image_2`
            ELSE `image_2`
        END,
        `image_3` = CASE 
            WHEN `p_image_3` IS NOT NULL THEN `p_image_3`
            ELSE `image_3`
        END,
        `video` = CASE 
            WHEN `p_video` IS NOT NULL THEN `p_video`
            ELSE `video`
        END
    WHERE 
        `product_id` = `p_product_id`;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_user` (IN `p_user_id` INT, IN `p_username` VARCHAR(32), IN `p_email` VARCHAR(64), IN `p_user_password` VARCHAR(64), IN `p_first_name` VARCHAR(64), IN `p_last_name` VARCHAR(64), IN `p_birth_date` DATE, IN `p_gender` TINYINT(1), IN `p_visibility` TINYINT(1), IN `p_profile_image` BLOB)   BEGIN
	UPDATE `users` SET
    `username` = `p_username`,
    `email` = `p_email`,
    `user_password` = `p_user_password`,
    `first_name` = `p_first_name`,
    `last_name` = `p_last_name`,
    `birth_date` = `p_birth_date`,
    `gender` = `p_gender`,
    `visibility` = `p_visibility`,
    `profile_image` = CASE 
            WHEN `p_profile_image` IS NOT NULL THEN `p_profile_image`
            ELSE `profile_image`
        END
    WHERE `user_id` = `p_user_id`;
END$$

DELIMITER ;
