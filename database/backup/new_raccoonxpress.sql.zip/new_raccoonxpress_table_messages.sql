
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL COMMENT 'Identificador del mensaje',
  `chat_id` int(11) NOT NULL COMMENT 'Identificador del chat al que pertenece el mensaje',
  `user_id` int(11) NOT NULL COMMENT 'Identificador del usuario autor del mensaje',
  `message` varchar(180) NOT NULL COMMENT 'Cuerpo del mensaje',
  `sent_at` datetime NOT NULL COMMENT 'Fecha y hora del envío del mensaje'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
