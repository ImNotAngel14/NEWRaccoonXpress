
-- --------------------------------------------------------

--
-- Estructura para la vista `product_overview`
--
DROP TABLE IF EXISTS `product_overview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `product_overview`  AS SELECT `p`.`product_id` AS `product_id`, `p`.`product_name` AS `product_name`, `p`.`description` AS `description`, `p`.`quotable` AS `quotable`, `p`.`price` AS `price`, `p`.`quantity` AS `quantity`, `p`.`active` AS `active`, `p`.`approved_by` AS `approved_by`, `p`.`image_1` AS `image_1`, `p`.`image_2` AS `image_2`, `p`.`image_3` AS `image_3`, `p`.`video` AS `video`, (select avg(`r`.`rate`) from (`reviews` `r` join `sale_details` `sd` on(`r`.`product_purchase_id` = `sd`.`sale_details_id`)) where `p`.`product_id` = `sd`.`product_id`) AS `average_rating`, (select sum(`sd`.`quantity`) from `sale_details` `sd` where `sd`.`product_id` = `p`.`product_id`) AS `units_sold` FROM `products` AS `p` ;
