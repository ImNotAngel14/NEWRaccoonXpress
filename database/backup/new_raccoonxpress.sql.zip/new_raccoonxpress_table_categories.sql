
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL COMMENT 'Identificador de categoria',
  `title` varchar(64) NOT NULL COMMENT 'Titulo de la categoria',
  `description` varchar(160) NOT NULL COMMENT 'Descripción de la categoría',
  `creation_date` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación de la categoría',
  `created_by` int(11) NOT NULL COMMENT 'Usuario creador de la categoria',
  `active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Bandera de categoria activa'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
