
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chats`
--

CREATE TABLE `chats` (
  `chat_id` int(11) NOT NULL COMMENT 'Identificador de la sala de chat',
  `seller_id` int(11) NOT NULL COMMENT 'Identificador del usuario vendedor',
  `client_id` int(11) NOT NULL COMMENT 'Identificador del usuario comprador',
  `active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Bandera de chat activo',
  `product_id` int(11) NOT NULL COMMENT 'Identificador del producto del cual se desprende el chat'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
