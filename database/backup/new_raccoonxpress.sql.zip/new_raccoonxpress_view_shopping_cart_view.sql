
-- --------------------------------------------------------

--
-- Estructura para la vista `shopping_cart_view`
--
DROP TABLE IF EXISTS `shopping_cart_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `shopping_cart_view`  AS SELECT `sc`.`quantity` AS `cart_quantity`, `sc`.`product_id` AS `product_id`, `sc`.`user_id` AS `user_id`, `p`.`product_name` AS `product_name`, `p`.`price` AS `price`, `p`.`quantity` AS `product_quantity`, `p`.`image_1` AS `image_1` FROM (`shopping_carts` `sc` join `products` `p` on(`sc`.`product_id` = `p`.`product_id`)) ;
