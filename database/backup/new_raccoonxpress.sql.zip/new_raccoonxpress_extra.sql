
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `fk_category_created_by_users` (`created_by`);

--
-- Indices de la tabla `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chat_id`),
  ADD KEY `fk_chats_seller_id_users` (`seller_id`),
  ADD KEY `fk_chats_client_id_users` (`client_id`),
  ADD KEY `fk_chats_product_id_products` (`product_id`);

--
-- Indices de la tabla `lists`
--
ALTER TABLE `lists`
  ADD PRIMARY KEY (`list_id`),
  ADD KEY `fk_lists_user_id_users` (`user_id`);

--
-- Indices de la tabla `list_items`
--
ALTER TABLE `list_items`
  ADD PRIMARY KEY (`list_item_id`),
  ADD KEY `fk_list_items_list_id_lists` (`list_id`),
  ADD KEY `fk_list_items_product_id_products` (`product_id`);

--
-- Indices de la tabla `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `fk_messages_chat_id_chats` (`chat_id`),
  ADD KEY `fk_messages_user_id_users` (`user_id`);

--
-- Indices de la tabla `paid_methods`
--
ALTER TABLE `paid_methods`
  ADD PRIMARY KEY (`paid_method_id`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_products_approved_by_users` (`approved_by`),
  ADD KEY `fk_products_created_by_users` (`created_by`),
  ADD KEY `fk_products_category_id_categories` (`category_id`);

--
-- Indices de la tabla `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`product_id`,`category_id`),
  ADD KEY `fk_product_categories_category_id_categories` (`category_id`);

--
-- Indices de la tabla `product_files`
--
ALTER TABLE `product_files`
  ADD PRIMARY KEY (`product_file_id`),
  ADD KEY `fk_product_files_product_id_products` (`product_id`);

--
-- Indices de la tabla `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `fk_reviews_product_purchase_id_sale_details` (`product_purchase_id`);

--
-- Indices de la tabla `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sale_id`),
  ADD KEY `fk_sales_buyer_id_users` (`buyer_id`);

--
-- Indices de la tabla `sale_details`
--
ALTER TABLE `sale_details`
  ADD PRIMARY KEY (`sale_details_id`),
  ADD KEY `fk_sale_details_sale_id_sales` (`sale_id`),
  ADD KEY `fk_sale_details_product_id_products` (`product_id`);

--
-- Indices de la tabla `shopping_carts`
--
ALTER TABLE `shopping_carts`
  ADD PRIMARY KEY (`user_id`,`product_id`),
  ADD KEY `fk_shopping_carts_product_id_products` (`product_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de categoria';

--
-- AUTO_INCREMENT de la tabla `chats`
--
ALTER TABLE `chats`
  MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la sala de chat';

--
-- AUTO_INCREMENT de la tabla `lists`
--
ALTER TABLE `lists`
  MODIFY `list_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la lista de productos';

--
-- AUTO_INCREMENT de la tabla `list_items`
--
ALTER TABLE `list_items`
  MODIFY `list_item_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador del producto en la lista';

--
-- AUTO_INCREMENT de la tabla `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador del mensaje';

--
-- AUTO_INCREMENT de la tabla `paid_methods`
--
ALTER TABLE `paid_methods`
  MODIFY `paid_method_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador del método de pago';

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de producto';

--
-- AUTO_INCREMENT de la tabla `product_files`
--
ALTER TABLE `product_files`
  MODIFY `product_file_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador del archivo para el producto';

--
-- AUTO_INCREMENT de la tabla `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la reseña';

--
-- AUTO_INCREMENT de la tabla `sales`
--
ALTER TABLE `sales`
  MODIFY `sale_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la venta';

--
-- AUTO_INCREMENT de la tabla `sale_details`
--
ALTER TABLE `sale_details`
  MODIFY `sale_details_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador del articulo de la venta';

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador de usuario';

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `fk_category_created_by_users` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`);

--
-- Filtros para la tabla `chats`
--
ALTER TABLE `chats`
  ADD CONSTRAINT `fk_chats_client_id_users` FOREIGN KEY (`client_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_chats_product_id_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `fk_chats_seller_id_users` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`);

--
-- Filtros para la tabla `lists`
--
ALTER TABLE `lists`
  ADD CONSTRAINT `fk_lists_user_id_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Filtros para la tabla `list_items`
--
ALTER TABLE `list_items`
  ADD CONSTRAINT `fk_list_items_list_id_lists` FOREIGN KEY (`list_id`) REFERENCES `lists` (`list_id`),
  ADD CONSTRAINT `fk_list_items_product_id_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Filtros para la tabla `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `fk_messages_chat_id_chats` FOREIGN KEY (`chat_id`) REFERENCES `chats` (`chat_id`),
  ADD CONSTRAINT `fk_messages_user_id_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_approved_by_users` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_products_category_id_categories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_products_created_by_users` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`);

--
-- Filtros para la tabla `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `fk_product_categories_category_id_categories` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `fk_product_categories_product_id_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Filtros para la tabla `product_files`
--
ALTER TABLE `product_files`
  ADD CONSTRAINT `fk_product_files_product_id_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Filtros para la tabla `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `fk_reviews_product_purchase_id_sale_details` FOREIGN KEY (`product_purchase_id`) REFERENCES `sale_details` (`sale_details_id`);

--
-- Filtros para la tabla `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `fk_sales_buyer_id_users` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`);

--
-- Filtros para la tabla `sale_details`
--
ALTER TABLE `sale_details`
  ADD CONSTRAINT `fk_sale_details_product_id_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `fk_sale_details_sale_id_sales` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`sale_id`);

--
-- Filtros para la tabla `shopping_carts`
--
ALTER TABLE `shopping_carts`
  ADD CONSTRAINT `fK_shopping_carts_user_id_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_shopping_carts_product_id_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
