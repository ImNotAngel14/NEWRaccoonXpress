
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_files`
--

CREATE TABLE `product_files` (
  `product_file_id` int(11) NOT NULL COMMENT 'Identificador del archivo para el producto',
  `product_id` int(11) NOT NULL COMMENT 'Identificador del producto al que pertenece el archivo',
  `file` longblob DEFAULT NULL COMMENT 'Datos binarios del archivo almacenado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
