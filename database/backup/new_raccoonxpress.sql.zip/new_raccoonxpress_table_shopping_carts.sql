
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `shopping_carts`
--

CREATE TABLE `shopping_carts` (
  `quantity` int(11) DEFAULT NULL COMMENT 'Cantidad en el carrito',
  `product_id` int(11) NOT NULL COMMENT 'Identificador del producto relacionado con el carrito',
  `user_id` int(11) NOT NULL COMMENT 'Identificador del usuario dueño del carrito'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
